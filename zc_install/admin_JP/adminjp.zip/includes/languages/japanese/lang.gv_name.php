<?php
/**
 * @copyright Copyright 2003-2022 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: Zcwilt 2020 Jun 02 New in v1.5.8-alpha $
*/

$define = [
    'TEXT_GV_NAME' => 'ギフト券',
    'TEXT_GV_NAMES' => 'ギフト券',
    'TEXT_GV_REDEEM' => '引換コード',
];

return $define;
